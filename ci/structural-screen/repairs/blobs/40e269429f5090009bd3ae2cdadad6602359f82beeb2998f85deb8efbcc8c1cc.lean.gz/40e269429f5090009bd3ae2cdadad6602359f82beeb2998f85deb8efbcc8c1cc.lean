module

public import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsStabForm
public import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.HermitianFormAtFrameLaws
public import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsSystem
public import Formalism.LocalToGlobal.ProjectiveLattices.ThShort
public import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEvenRepsTensorLatticeAndSum
public import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsBaseClassLevelAdapted
public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ThExprUniqOfChartIndep2
public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.Taylor
public import Development.AbelianVarietyTheory.Proofs.CovolumeBounds.DifferentiableOnOfTendstoLocallyUniformlyOn
public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.CardToMultisetEqDegree
public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.ExistsTranslationSectionsUniversalObject
public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.FramedPointBaseChangeLaws
public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.ShortThetaValueExistsUniqueNaturalOfLaws
public import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.FockHxDifferentiable
public import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.HarmonicConnectionValueEqPolynomialDerivativeStatement
public import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.SectionsReadAsTranslatesAtScaledPointStatement
public import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ThetaSeriesTestFunctionHolomorphicWeight
public import Development.AbelianVarietyTheory.Proofs.UniformizationProofs.AllUniformizationLawsHold
public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.PullbackSections.HolomorphicFamilies.CmHostUnitAddConjEqOne
import Mathlib.Algebra.Order.Floor.Extended
import Mathlib.Algebra.Order.Floor.Semifield
import Mathlib.Algebra.Order.Interval.Basic
import Mathlib.Analysis.Complex.UpperHalfPlane.Basic
import Mathlib.Analysis.Normed.Algebra.GelfandRadius
import Mathlib.Analysis.SpecialFunctions.Bernstein
import Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp
import Mathlib.Combinatorics.Enumerative.DyckWord
import Mathlib.Combinatorics.SimpleGraph.Triangle.Removal
import Mathlib.Data.NNRat.Floor
import Mathlib.Data.Nat.Choose.Multinomial
import Mathlib.Geometry.Euclidean.Volume.Basic
import Mathlib.NumberTheory.Chebyshev
import Mathlib.NumberTheory.Height.NumberField
import Mathlib.NumberTheory.Height.Projectivization
import Mathlib.NumberTheory.LucasLehmer
import Mathlib.NumberTheory.SelbergSieve
import Mathlib.RingTheory.Henselian
import Mathlib.RingTheory.Radical.NatInt
import Mathlib.RingTheory.RegularLocalRing.Defs
import Mathlib.Tactic.Echelon.Zsqrtd
import Mathlib.Tactic.Inclusion.Extension.Core.Core
import Mathlib.Tactic.Inclusion.Extension.Interval.BinarySplit
import Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Exp
import Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Hypotheses
import Mathlib.Tactic.Inclusion.Extension.IntervalInt.Basic
import Mathlib.Tactic.Inclusion.Extension.IntervalInt.Hypotheses
import Mathlib.Tactic.Linter.HaveILetI
import Mathlib.Tactic.Linter.Style
import Mathlib.Tactic.NormNum.Irrational
import Mathlib.Tactic.NormNum.IsCoprime
import Mathlib.Tactic.NormNum.IsSquare
import Mathlib.Tactic.NormNum.LegendreSymbol
import Mathlib.Tactic.NormNum.ModEq
import Mathlib.Tactic.NormNum.NatFib
import Mathlib.Tactic.NormNum.NatLog
import Mathlib.Tactic.NormNum.NatSqrt
import Mathlib.Tactic.NormNum.Ordinal
import Mathlib.Tactic.NormNum.Parity
import Mathlib.Tactic.NormNum.Prime
import Mathlib.Tactic.NormNum.RealSqrt
import Formalism.LocalToGlobal.ProjectiveLattices.JFDFree
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.HMatMulVecPerCrd
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.RationalSchwartzBruhatAlgebraIntegralLinear
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.WeilActionPreservesThetaAndInnerProduct
import Mathlib.RingTheory.Coalgebra.IsFrobenius
import Mathlib.RingTheory.WittVector.IsPoly
import Mathlib.Tactic.Basify
import Mathlib.Tactic.ENatToNat
import Mathlib.Tactic.Polynomial.Basic
import Mathlib.Tactic.ReduceModChar

-- This file was produced by scripts/clump.py from the modules listed below.
-- Members: Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRoots, Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRootsStatement, Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEvenRepsTensorLatticeAndSumStatement, Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ShortThetaValueComplexPointEqClassicalTheta

-- clump: shared namespace opens

open AlgebraicGeometry CategoryTheory Limits MonoidalCategory CartesianMonoidalCategory MonObj NumberField Matrix Complex
open ReciprocityTheory.ChartRestriction.G ReciprocityTheory.ChartRestriction.G.Semi ReciprocityTheory.ChartRestriction.G.Out ReciprocityTheory.ChartRestriction.G.FD GlobalTheory GlobalTheory.ThFr

@[expose] public section -- clump member: Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRoots
open ReciprocityTheory.ChartRestriction.G.Geo.Tor hiding Level
open GlobalTheory.SW hiding Level
open Formalism.L2.Pj Formalism.L2.PjFree
open scoped ComplexConjugate Classical
attribute [local instance] Over.cartesianMonoidalCategory
open GlobalTheory.Dict

namespace GlobalTheory.Dict.ZGeo

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {H : Host E} {Dw : Datum H} {l : Geo.Tor.Level H}
  {Xo : Moduli Dw l} {c : Coeff l} [Algebra c.F ℂ] {r g : ℕ} {X : Data E r}
  {bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ} {idx : Fin g ≃ X.Ψ × Fin r} {e : Fin g ≃ Lt1 Dw} {x : Frame X.Ψ r}
  {L : Lt E r} {y : FrPt Xo c ℂ} (A : AnFib X bas idx e x L y)

theorem epi_spMap {K k : Type} [Field K] [Field k] (β : K →+* k) : Epi (spMap β) := by
  have hff : (CommRingCat.ofHom β).hom.FaithfullyFlat := by
    letI := β.toAlgebra
    show Module.FaithfullyFlat K k
    infer_instance
  obtain ⟨h1, h2⟩ := (AlgebraicGeometry.flat_and_surjective_SpecMap_iff (CommRingCat.ofHom β)).2 hff
  exact AlgebraicGeometry.Flat.epi_of_flat_of_surjective _

theorem ex_add (u v : Fin r → E) : A.ex (pv X idx x (u + v)) = A.ex (pv X idx x u) * A.ex (pv X idx x v) := by
  have h : pv X idx x (u + v) = pv X idx x u + pv X idx x v := by
    funext j
    simp only [pv, per_add, Function.comp_apply, Pi.add_apply]
  rw [h, A.ex_add]

theorem ex_pow (m : ℕ) (v : Fin r → E) : A.ex (pv X idx x v) ^ m = A.ex (pv X idx x (m • v)) := by
  induction m with
  | zero =>
    have hz : pv X idx x 0 = 0 := by
      funext j
      simp only [pv, per_zero, Function.comp_apply, Pi.zero_apply]
    have h0 : A.ex 0 = 1 := by
      have h := A.ex_add 0 0
      rw [add_zero] at h
      exact mul_left_cancel (a := A.ex 0) (b := A.ex 0) (c := 1) (by rw [_root_.mul_one, ← h])
    rw [pow_zero, zero_smul, hz, h0]
  | succ m ih =>
    rw [pow_succ, ih, ← GlobalTheory.Dict.ZGeo.ex_add, succ_nsmul]

theorem ex_of_mem {v : Fin r → E} (hv : v ∈ L) : A.ex (pv X idx x v) = 1 := by
  exact (A.ex_ker _).2 ⟨v, hv, rfl⟩

theorem ex_act (a : 𝓞 E) (v : Fin r → E) :
    A.ex (pv X idx x v) ≫ Xo.univ.t.act.act a = A.ex (pv X idx x ((a : E) • v)) := by
  rw [pv_smul idx x (a : E) v, A.ex_lin]

theorem ex_prod {n : ℕ} (v : Fin n → Fin r → E) :
    (List.ofFn fun j => A.ex (pv X idx x (v j))).prod = A.ex (pv X idx x (∑ j, v j)) := by
  induction n with
  | zero =>
    have h0 := GlobalTheory.Dict.ZGeo.ex_pow A 0 (0 : Fin r → E)
    rw [pow_zero, smul_zero] at h0
    rw [List.ofFn_zero, List.prod_nil, Fin.sum_univ_zero]
    exact h0
  | succ n ih =>
    rw [List.ofFn_succ, List.prod_cons, ih (fun j => v j.succ), Fin.sum_univ_succ, GlobalTheory.Dict.ZGeo.ex_add]

theorem sub_mem_of_ex_eq (hinj : Function.Injective (pv X idx x)) {u v : Fin r → E}
    (h : A.ex (pv X idx x u) = A.ex (pv X idx x v)) : u - v ∈ L := by
  have h1 : A.ex (pv X idx x (u - v)) = 1 := by
    have h2 := GlobalTheory.Dict.ZGeo.ex_add A (u - v) v
    rw [sub_add_cancel, h] at h2
    exact mul_right_cancel (a := A.ex (pv X idx x (u - v))) (b := A.ex (pv X idx x v)) (c := 1)
      (by rw [_root_.one_mul]; exact h2.symm)
  obtain ⟨w, hw, hpw⟩ := (A.ex_ker _).1 h1
  rw [hinj hpw]
  exact hw


omit [IsCMField E] in
theorem sum_mem_of_tens {n : ℕ} {Λ : Lt E n} {mu : Matrix (Fin n) (Fin n) E}
    (hmu : ∀ v ∈ Λ, mu.mulVec v ∈ stdLat E n) {u : Matrix (Fin n) (Fin r) E} (hu : u ∈ tens Λ L) (i : Fin n) :
    ∑ j, mu i j • u j ∈ L := by
  unfold tens at hu
  induction hu using AddSubgroup.closure_induction with
  | mem y hy =>
    obtain ⟨w, hw, l', hl', rfl⟩ := hy
    have hi : (mu.mulVec w) i ∈ (1 : Submodule (𝓞 E) E) := by
      have hmw := hmu w hw
      rw [stdLat, Submodule.mem_pi] at hmw
      exact hmw i (Set.mem_univ i)
    obtain ⟨c', hc⟩ := Submodule.mem_one.1 hi
    have hs : ∑ j, mu i j • vecMulVec w l' j = (mu.mulVec w) i • l' := by
      funext k
      simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, vecMulVec_apply, mulVec, dotProduct,
        Finset.sum_mul]
      refine Finset.sum_congr rfl fun j _ => ?_
      ring
    rw [hs, ← hc, algebraMap_smul]
    exact L.smul_mem c' hl'
  | zero =>
    have hs : ∑ j, mu i j • (0 : Matrix (Fin n) (Fin r) E) j = 0 :=
      Finset.sum_eq_zero fun j _ => by
        rw [show (0 : Matrix (Fin n) (Fin r) E) j = 0 from rfl, smul_zero]
    rw [hs]
    exact L.zero_mem
  | add y z _ _ hy hz =>
    have hs : ∑ j, mu i j • (y + z) j = ∑ j, mu i j • y j + ∑ j, mu i j • z j := by
      rw [← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [← smul_add]
      rfl
    rw [hs]
    exact L.add_mem hy hz
  | neg y _ hy =>
    have hs : ∑ j, mu i j • (-y) j = -∑ j, mu i j • y j := by
      rw [← Finset.sum_neg_distrib]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [← smul_neg]
      rfl
    rw [hs]
    exact L.neg_mem hy

omit [IsCMField E] in
theorem nsmul_inv_smul {N : ℕ} (hN : 0 < N) (v : Fin r → E) : N • ((N : E)⁻¹ • v) = v := by
  rw [← Nat.cast_smul_eq_nsmul E, smul_smul, mul_inv_cancel₀ (Nat.cast_ne_zero.mpr hN.ne'), one_smul]

theorem inZh {n N : ℕ} (hN : 0 < N) {Λ : Lt E n} {u : Matrix (Fin n) (Fin r) E} (hu : u ∈ tens Λ L)
    (h2 : ∀ b, ∃ u' ∈ L, N • u b = (2 : ℕ) • u') :
    InZh Xo (⟨Λ⟩ : GenLat E n) N (fun b => A.ex (pv X idx x ((N : E)⁻¹ • u b))) := by
  have hN0 : (N : E) ≠ 0 := Nat.cast_ne_zero.mpr hN.ne'
  unfold InZh
  refine ⟨fun b => ?_, fun mu hmu cm hcm i => ?_⟩
  · obtain ⟨u', hu', he⟩ := h2 b
    rw [GlobalTheory.Dict.ZGeo.ex_pow, sq, mul_smul, nsmul_inv_smul hN, he]
    exact ex_of_mem A (nsmul_mem hu' 2)
  · have hj : ∀ j, A.ex (pv X idx x ((N : E)⁻¹ • u j)) ≫ Xo.univ.t.act.act (cm i j) =
        A.ex (pv X idx x (mu i j • u j)) := by
      intro j
      rw [ex_act, hcm, smul_smul]
      congr 3
      rw [mul_comm ((N : E) * mu i j) ((N : E)⁻¹), ← _root_.mul_assoc, inv_mul_cancel₀ hN0, _root_.one_mul]
    simp only [hj]
    rw [ex_prod]
    exact ex_of_mem A (sum_mem_of_tens hmu hu i)

theorem geoInj (hinj : Function.Injective (pv X idx x)) {n N : ℕ} (hN : 0 < N) {Jx : Type}
    (u : Jx → Matrix (Fin n) (Fin r) E) (hu : ∀ i i', (∀ b, ∃ u' ∈ L, u i b - u i' b = N • u') → i = i') :
    GeoInj Xo y.x (fun i b => A.ex (pv X idx x ((N : E)⁻¹ • u i b))) := by
  unfold GeoInj
  intro k _ ψ g hg i i' hii
  have hepi : Epi g := by
    have : Epi g.left := by
      rw [hg]
      exact epi_spMap ψ
    exact Over.epi_of_epi_left g
  apply hu
  intro b
  have hb : g ≫ A.ex (pv X idx x ((N : E)⁻¹ • u i b)) = g ≫ A.ex (pv X idx x ((N : E)⁻¹ • u i' b)) :=
    congrFun hii b
  have he := (cancel_epi g).1 hb
  refine ⟨(N : E)⁻¹ • u i b - (N : E)⁻¹ • u i' b, sub_mem_of_ex_eq A hinj he, ?_⟩
  rw [← smul_sub, nsmul_inv_smul hN]


omit [Algebra c.F ℂ] in
theorem levPt_levRep {S : Type} [CommRing S] (x0 : Sp S ⟶ Xo.X) (a : Dw.La) :
    levPt Xo x0 (levRep (l := l) (Submodule.Quotient.mk a)) = levPt Xo x0 a := by
  have hs : (Submodule.Quotient.mk (levRep (l := l) (Submodule.Quotient.mk a : LevQ Dw l)) : LevQ Dw l) =
      Submodule.Quotient.mk a :=
    Classical.choose_spec (Submodule.Quotient.mk_surjective _ _)
  have hq := (Submodule.Quotient.eq _).1 hs
  have he : Xo.univ.eta (levRep (l := l) (Submodule.Quotient.mk a : LevQ Dw l)) = Xo.univ.eta a := by
    rw [← sub_add_cancel (levRep (l := l) (Submodule.Quotient.mk a : LevQ Dw l)) a, Xo.univ.eta_add,
      Xo.univ.eta_ker _ hq, _root_.one_mul]
  unfold levPt
  rw [he]


theorem roots {N : ℕ} (hN : 0 < N) {mk : Dw.La →ₗ[𝓞 E] (Fin r → E)} (hm : IsMark l L mk) (hA : A.Marked mk)
    (hM : l.M ∣ N) {Y : Fin r → E} {q : LevQ Dw l}
    (h1 : ∃ a ∈ Mfr l • (⊤ : Submodule (𝓞 E) Dw.La), Submodule.Quotient.mk a = q ∧ Y - ((l.M : E)⁻¹) • mk a ∈ L)
    (h2 : ∃ j : ℕ, ∀ s ∈ l.Mb ^ j, ∃ u ∈ L, s • Y = (2 * N) • u) :
    A.ex (pv X idx x ((N : E)⁻¹ • Y)) ^ N = levPt Xo y.x (levRep q) ∧
      (∃ j : ℕ, KilledBy Xo (l.Mb ^ j) (A.ex (pv X idx x ((N : E)⁻¹ • Y)))) ∧
      ∃ u ∈ L, (N ^ 2 : ℕ) • ((N : E)⁻¹ • Y) = (2 : ℕ) • u := by
  have hN0 : (N : E) ≠ 0 := Nat.cast_ne_zero.mpr hN.ne'
  obtain ⟨a, ha, hq, hw⟩ := h1
  obtain ⟨j, hj⟩ := h2
  refine ⟨?_, ⟨j, ?_⟩, ?_⟩
  · rw [GlobalTheory.Dict.ZGeo.ex_pow, nsmul_inv_smul hN, ← hq, levPt_levRep, hA a ha,
      ← sub_add_cancel Y ((l.M : E)⁻¹ • mk a), GlobalTheory.Dict.ZGeo.ex_add, ex_of_mem A hw, _root_.one_mul]
  · intro s hs
    rw [ex_act]
    apply ex_of_mem A
    obtain ⟨w, hw', hsw⟩ := hj s hs
    have e : (s : E) • ((N : E)⁻¹ • Y) = w + w := by
      funext t
      have h3 := congrFun hsw t
      simp only [Pi.smul_apply, Pi.add_apply, smul_eq_mul, nsmul_eq_mul, Nat.cast_mul, Nat.cast_ofNat] at h3 ⊢
      have hs' : algebraMap (𝓞 E) E s = (s : E) := rfl
      rw [Algebra.smul_def, hs'] at h3
      field_simp
      linear_combination h3
    rw [e]
    exact L.add_mem hw' hw'
  · have hMb : ((l.M : ℕ) : 𝓞 E) ∈ l.Mb := by
      have hm2 : ((l.M : ℕ) : 𝓞 E) ∈ l.Mb * l.Mb.map (H.bar : 𝓞 E →+* 𝓞 E) := by
        rw [l.prod]
        exact Ideal.mem_span_singleton_self _
      exact SetLike.le_def.1 (Ideal.mul_le_left (I := l.Mb) (J := l.Mb.map (H.bar : 𝓞 E →+* 𝓞 E))) hm2
    obtain ⟨u', hu', hsu⟩ := hj _ (Ideal.pow_mem_pow hMb j)
    obtain ⟨t, ht⟩ := (l.odd.pow : Odd (l.M ^ j))
    obtain ⟨k, hk⟩ := hM
    have hM0 : 0 < l.M := by have := l.three_le; omega
    have e1 : N • ((l.M : E)⁻¹ • mk a) = k • mk a := by
      rw [hk, mul_comm, mul_smul, nsmul_inv_smul hM0]
    have hV : N • Y ∈ L := by
      have e2 : N • Y = N • (Y - (l.M : E)⁻¹ • mk a) + N • ((l.M : E)⁻¹ • mk a) := by
        rw [← smul_add, sub_add_cancel]
      rw [e2, e1]
      exact L.add_mem (nsmul_mem hw N) (nsmul_mem (hm.mem a) k)
    refine ⟨N • N • u' - t • (N • Y), L.sub_mem (nsmul_mem (nsmul_mem hu' N) N) (nsmul_mem hV t), ?_⟩
    have ht' : ((l.M : E)) ^ j = 2 * (t : E) + 1 := by exact_mod_cast ht
    funext i
    have h3 := congrFun hsu i
    simp only [← Nat.cast_smul_eq_nsmul E] at h3 ⊢
    simp only [Pi.smul_apply, Pi.sub_apply, smul_eq_mul, Nat.cast_pow, Nat.cast_mul, Nat.cast_ofNat] at h3 ⊢
    rw [Algebra.smul_def, map_pow, map_natCast, ht'] at h3
    have hh : (N : E) ^ 2 * ((N : E)⁻¹ * Y i) = N * Y i := by
      rw [sq, _root_.mul_assoc, mul_inv_cancel_left₀ hN0]
    linear_combination hh + (N : E) * h3

end GlobalTheory.Dict.ZGeo

namespace GlobalTheory.Dict

theorem points_inZh_geoInj_roots : ∀ (E : Type) [Field E] [NumberField E] [IsCMField E] (H : Host E) (Dw : Datum H) (l : Geo.Tor.Level H) (Xo : Moduli Dw l) (c : Coeff l) [Algebra c.F ℂ] (r g : ℕ) (X : Data E r) (bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ) (idx : Fin g ≃ X.Ψ × Fin r) (e : Fin g ≃ Lt1 Dw) (x : Frame X.Ψ r) (L : Lt E r) (y : FrPt Xo c ℂ) (A : AnFib X bas idx e x L y), IsSympl X bas → x ∈ X.dom → SelfD X L → ∀ (n N : ℕ) (Λ : Lt E n), 0 < N → (∀ (Jx : Type) (u : Jx → Matrix (Fin n) (Fin r) E), (∀ i, u i ∈ tens Λ L ∧ ∀ b, ∃ u' ∈ L, N • u i b = (2 : ℕ) • u') → (∀ i i', (∀ b, ∃ u' ∈ L, u i b - u i' b = N • u') → i = i') → (∀ i, InZh Xo (⟨Λ⟩ : GenLat E n) N (fun b => A.ex (pv X idx x ((N : E)⁻¹ • u i b)))) ∧ GeoInj Xo y.x (fun i b => A.ex (pv X idx x ((N : E)⁻¹ • u i b)))) ∧ ∀ mk : Dw.La →ₗ[𝓞 E] (Fin r → E), IsMark l L mk → A.Marked mk → l.M ∣ N → ∀ Y : (Fin n → LevQ Dw l) → Matrix (Fin n) (Fin r) E, IsRoots l L mk N Y → ∀ q b, A.ex (pv X idx x ((N : E)⁻¹ • Y q b)) ^ N = levPt Xo y.x (levRep (q b)) ∧ (∃ j : ℕ, KilledBy Xo (l.Mb ^ j) (A.ex (pv X idx x ((N : E)⁻¹ • Y q b)))) ∧ ∃ u ∈ L, (N ^ 2 : ℕ) • ((N : E)⁻¹ • Y q b) = (2 : ℕ) • u := by
  intro E _ _ _ H Dw l Xo c _ r g X bas idx e x L y A hs hx _ n N Λ hN
  have hinj : Function.Injective (pv X idx x) :=
    (hx_laws E r X g bas idx 0 hs ⟨0, rfl⟩ x hx).2.2.2.2.2.1
  refine ⟨fun Jx u hu hdist => ⟨fun i => ZGeo.inZh A hN (hu i).1 (hu i).2, ZGeo.geoInj A hinj hN u hdist⟩, ?_⟩
  intro mk hm hA hM Y hY q b
  exact ZGeo.roots A hN hm hA hM (hY q b).1 (hY q b).2

end GlobalTheory.Dict
end -- clump:auto

@[expose] public section -- clump member: Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRootsStatement
open ReciprocityTheory.ChartRestriction.G.Geo.Tor hiding Level
open GlobalTheory.SW hiding Level
open Formalism.L2.Pj Formalism.L2.PjFree
open scoped ComplexConjugate Classical
attribute [local instance] Over.cartesianMonoidalCategory
open GlobalTheory.Dict

theorem _root_.GlobalTheory.T.analyticFibre_isotropic_points_injective_roots : ∀ (E : Type) [Field E] [NumberField E] [IsCMField E] (H : Host E) (Dw : Datum H) (l : Geo.Tor.Level H) (Xo : Moduli Dw l) (c : Coeff l) [Algebra c.F ℂ] (r g : ℕ) (X : Data E r) (bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ) (idx : Fin g ≃ X.Ψ × Fin r) (e : Fin g ≃ Lt1 Dw) (x : Frame X.Ψ r) (L : Lt E r) (y : FrPt Xo c ℂ) (A : AnFib X bas idx e x L y), IsSympl X bas → x ∈ X.dom → SelfD X L → ∀ (n N : ℕ) (Λ : Lt E n), 0 < N → (∀ (Jx : Type) (u : Jx → Matrix (Fin n) (Fin r) E), (∀ i, u i ∈ tens Λ L ∧ ∀ b, ∃ u' ∈ L, N • u i b = (2 : ℕ) • u') → (∀ i i', (∀ b, ∃ u' ∈ L, u i b - u i' b = N • u') → i = i') → (∀ i, InZh Xo (⟨Λ⟩ : GenLat E n) N (fun b => A.ex (pv X idx x ((N : E)⁻¹ • u i b)))) ∧ GeoInj Xo y.x (fun i b => A.ex (pv X idx x ((N : E)⁻¹ • u i b)))) ∧ ∀ mk : Dw.La →ₗ[𝓞 E] (Fin r → E), IsMark l L mk → A.Marked mk → l.M ∣ N → ∀ Y : (Fin n → LevQ Dw l) → Matrix (Fin n) (Fin r) E, IsRoots l L mk N Y → ∀ q b, A.ex (pv X idx x ((N : E)⁻¹ • Y q b)) ^ N = levPt Xo y.x (levRep (q b)) ∧ (∃ j : ℕ, KilledBy Xo (l.Mb ^ j) (A.ex (pv X idx x ((N : E)⁻¹ • Y q b)))) ∧ ∃ u ∈ L, (N ^ 2 : ℕ) • ((N : E)⁻¹ • Y q b) = (2 : ℕ) • u := by
  first | exact @GlobalTheory.Dict.points_inZh_geoInj_roots
end -- clump:auto

@[expose] public section -- clump member: Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEvenRepsTensorLatticeAndSumStatement
open ReciprocityTheory.ChartRestriction.G.Geo.Tor hiding Level
open GlobalTheory.SW hiding Level
open Formalism.L2.Pj Formalism.L2.PjFree
open scoped ComplexConjugate Classical
attribute [local instance] Over.cartesianMonoidalCategory
open GlobalTheory.Dict

theorem _root_.GlobalTheory.T.exists_even_reps_tensorLattice_and_sum : ∀ (E : Type) [Field E] [NumberField E] [IsCMField E] (r : ℕ) (X : Data E r) (g : ℕ) (bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ) (idx : Fin g ≃ X.Ψ × Fin r) (n : ℕ), IsSympl X bas → Even n → ∀ w : E, IsIntegral ℤ w → w + cc w = 1 → ∀ L : Lt E r, SelfD X L → ∀ Λ ∈ Vset E n 1, ∀ N : ℕ, Odd N → Ideal.span {(N : 𝓞 E)} • stdLat E n ≤ Λ → ∃ u : Fin ((⟨Λ⟩ : GenLat E n).zCard N r) → Matrix (Fin n) (Fin r) E, (∀ i, u i ∈ tens Λ L ∧ ∀ b, ∃ u' ∈ L, N • u i b = (2 : ℕ) • u') ∧ (∀ i i', (∀ b, ∃ u' ∈ L, u i b - u i' b = N • u') → i = i') ∧ 0 < (⟨Λ⟩ : GenLat E n).zCard N r ∧ 0 < (⟨Λ⟩ : GenLat E n).mIdx N r ∧ ∀ v : TF n g, IsVac X bas w (tens (stdL E n) L) v → ∑ i, heisG X bas (u i) v = (((⟨Λ⟩ : GenLat E n).zCard N r : ℕ) : ℂ) • projA X bas w (tens Λ L) v := by
  first | exact @GlobalTheory.Dict.ZLat.exists_reps_sum
end -- clump:auto

@[expose] public section -- clump member: Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ShortThetaValueComplexPointEqClassicalTheta
open ReciprocityTheory.ChartRestriction.G.Geo.Tor hiding Level
open GlobalTheory.SW hiding Level
open Formalism.L2.Pj Formalism.L2.PjFree
open scoped ComplexConjugate Classical
attribute [local instance] Over.cartesianMonoidalCategory
open GlobalTheory.Dict

namespace GlobalTheory.Dict.ShortVal

section Deriv

open scoped ContDiff

variable {W : Type} [NormedAddCommGroup W] [NormedSpace ℂ W]

open ReciprocityTheory.ChartRestriction.G.PullbackSections in
theorem polyDeriv_eq_sum {θ : W → ℂ} {x : W} (hθ : ContDiffAt ℂ ω θ x) {T : Type}
    (P : MvPolynomial T ℂ) (u : T → W) :
    I2.polyDeriv P u θ x =
      ∑ m ∈ P.support, P.coeff m * mD θ x ((Finsupp.toMultiset m).map u) := by
  unfold I2.polyDeriv
  refine Finset.sum_congr rfl fun m _ => ?_
  congr 1
  have hL : (((Finsupp.toMultiset m).toList.map u : List W) : Multiset W) =
      (Finsupp.toMultiset m).map u := by
    rw [← Multiset.map_coe, Multiset.coe_toList]
  rw [← hL, mD_coe hθ, lD_eq θ x _ (n := Multiset.card (Finsupp.toMultiset m))
    (by rw [List.length_map, Multiset.length_toList])]
  congr 1
  funext k
  simp [List.get_eq_getElem]

theorem polyDeriv_rename {θ : W → ℂ} {x : W} (hθ : ContDiffAt ℂ ω θ x) {T κ : Type} (ρ : T → κ)
    (hρ : Function.Injective ρ) (P : MvPolynomial T ℂ) (v : κ → W) :
    I2.polyDeriv (MvPolynomial.rename ρ P) v θ x = I2.polyDeriv P (v ∘ ρ) θ x := by
  rw [polyDeriv_eq_sum hθ, polyDeriv_eq_sum hθ, MvPolynomial.support_rename_of_injective hρ,
    Finset.sum_image (fun a _ b _ h => Finsupp.mapDomain_injective hρ h)]
  refine Finset.sum_congr rfl fun m _ => ?_
  rw [MvPolynomial.coeff_rename_mapDomain ρ hρ, ← Finsupp.toMultiset_map, Multiset.map_map]

end Deriv

theorem isHomogeneous_of_rowDeg {T k : Type} [Fintype T] [Field k] {m : T → ℕ} {n : ℕ} {a : T → ℕ → ℕ}
    {P : MvPolynomial (Letter T m n) k} (h : RowDeg m n k a P) : P.IsHomogeneous P.totalDegree := by
  have h1 : P.IsHomogeneous (∑ σ, ∑ i : Fin (m σ), a σ i) := by
    intro d hd
    have := h d (MvPolynomial.mem_support_iff.2 hd)
    have e : Finsupp.weight (1 : Letter T m n → ℕ) d = d.degree := by
      rw [Finsupp.degree_eq_weight_one]; rfl
    rw [e, Finsupp.degree_eq_sum, Fintype.sum_sigma]
    refine Finset.sum_congr rfl fun σ _ => ?_
    rw [Fintype.sum_prod_type]
    exact Finset.sum_congr rfl fun i _ => this σ i
  by_cases h0 : P = 0
  · rw [h0]; exact MvPolynomial.isHomogeneous_zero _ _ _
  · rw [h1.totalDegree h0]; exact h1

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r g n : ℕ}

theorem stdLat_eq : stdLat E n = stdL E n := by
  refine le_antisymm (fun v hv => ?_) (Submodule.span_le.2 ?_)
  · have h : ∀ i, ∃ a : 𝓞 E, algebraMap (𝓞 E) E a = v i := fun i =>
      Submodule.mem_one.1 (hv i (Set.mem_univ i))
    choose a ha using h
    have e : v = ∑ i, a i • (Pi.single i 1 : Fin n → E) := by
      funext j
      simp [Finset.sum_apply, Pi.single_apply, Algebra.smul_def, ha]
    rw [e]
    exact Submodule.sum_mem _ fun i _ => Submodule.smul_mem _ _ (Submodule.subset_span ⟨i, rfl⟩)
  · rintro _ ⟨i, rfl⟩ j -
    by_cases h : j = i
    · subst h; simpa using Submodule.mem_one.2 ⟨1, map_one _⟩
    · simp [h]

theorem unimod_trivAt {M : ℕ} {Λ : Lt E n} (h : Λ ∈ Vset E n M) :
    (⟨Λ⟩ : GenLat E n).Unimod ∧ (⟨Λ⟩ : GenLat E n).TrivAt M := by
  obtain ⟨-, h2, s, -, hs, h3, h4⟩ := h
  refine ⟨fun v => (h2 v).trans (forall₂_congr fun w _ => ?_), s, hs, ?_, ?_⟩
  · have e : herm 1 v w = IsCMField.complexConj E (∑ j, IsCMField.complexConj E (v j) * w j) := by
      simp [herm, cc, Matrix.one_apply]
    rw [e, show ∀ t, IsCMField.complexConj E t = (IsCMField.complexConj E).restrictScalars ℤ t from fun _ => rfl,
      isIntegral_algEquiv]
    exact ⟨fun hi => ⟨⟨_, hi⟩, rfl⟩, fun ⟨a, ha⟩ => ha ▸ a.isIntegral_coe⟩
  · rw [Submodule.ideal_span_singleton_smul, stdLat_eq]
    rintro _ ⟨v, hv, rfl⟩
    simpa [Nat.cast_smul_eq_nsmul] using h3 v hv
  · rw [Submodule.ideal_span_singleton_smul, stdLat_eq]
    rintro _ ⟨v, hv, rfl⟩
    simpa [Nat.cast_smul_eq_nsmul] using h4 v hv

variable {X : Data E r} {bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ} (idx : Fin g ≃ X.Ψ × Fin r)

theorem isSB_smul (c : ℂ) {φ : TF n g} (h : IsSB φ) : IsSB (c • φ) :=
  (isSB_algebra_haar_linear ℚ _ _ φ φ h h).2.1 c

theorem isSB_sum {T : Type} (s : Finset T) (f : T → TF n g) (hf : ∀ i, IsSB (f i)) : IsSB (∑ i ∈ s, f i) :=
  Finset.sum_induction f IsSB (fun a b ha hb => (isSB_algebra_haar_linear ℚ _ _ a b ha hb).1) isSB_zero
    fun i _ => hf i

theorem thA_sum (hs : IsSympl X bas) {x : Frame X.Ψ r} (hx : x ∈ X.dom) {T : Type} (s : Finset T)
    (f : T → TF n g) (hf : ∀ i, IsSB (f i)) :
    thA X bas idx (∑ i ∈ s, f i) x = ∑ i ∈ s, thA X bas idx (f i) x := by
  induction s using Finset.induction_on with
  | empty => simpa using UnAct.thA_smul (X := X) (bas := bas) idx x 0 (0 : TF n g)
  | insert a s ha ih =>
    rw [Finset.sum_insert ha, Finset.sum_insert ha, ← ih]
    exact UnAct.thA_add idx hs hx (hf a) (isSB_sum s f hf)

theorem polyDeriv_thA_sum (hs : IsSympl X bas) {x : Frame X.Ψ r} (hx : x ∈ X.dom) {σ T : Type} [Fintype T]
    (P : MvPolynomial σ ℂ) (D : σ → Fin n → Fin g → ℂ) (w : T → ℂ) (f : T → TF n g) (hf : ∀ i, IsSB (f i)) :
    I2.polyDeriv P D (thA X bas idx (∑ i, w i • f i) x) 0 =
      ∑ i, w i * I2.polyDeriv P D (thA X bas idx (f i) x) 0 := by
  rw [← Jet.polyDeriv_sum_fun P D _ w _ fun i _ => ThetaHol.differentiable_thA idx hs (hf i) hx,
    thA_sum idx hs hx _ _ fun i => isSB_smul _ (hf i)]
  congr 1
  ext z
  simp only [Finset.sum_apply, UnAct.thA_smul, Pi.smul_apply, smul_eq_mul]

theorem sum_polyDeriv (hs : IsSympl X bas) (hn : Even n) {x : Frame X.Ψ r} (hx : x ∈ X.dom) {σ Q J : Type}
    [Fintype Q] [Fintype J] {P : MvPolynomial σ ℂ} {d : ℕ} (hP : P.IsHomogeneous d) (D : σ → Fin n → Fin g → ℂ)
    (w : Q → ℂ) (Y : Q → Matrix (Fin n) (Fin r) E) (u : J → Matrix (Fin n) (Fin r) E) {v p : TF n g}
    (hv : IsSB v) (hp : IsSB p) {t : ℂ} (h : ∑ i, heisG X bas (u i) v = t • p) (κ N : ℂ) :
    ∑ q, w q * ∑ i, I2.polyDeriv P D
        (fun z => κ * thA X bas idx (heisG X bas (Y q) (heisG X bas (u i) v)) x (N • z)) 0 =
      N ^ d * t * κ * I2.polyDeriv P D (thA X bas idx (∑ q, w q • heisG X bas (Y q) p) x) 0 := by
  have hh := (heisG_laws E r X g bas idx n hs hn).2.2.2
  have hsb (q i) : IsSB (heisG X bas (Y q) (heisG X bas (u i) v)) := (hh _ _ (hh _ _ hv).1).1
  rw [polyDeriv_thA_sum idx hs hx P D w _ fun q => (hh _ _ hp).1, Finset.mul_sum]
  refine Finset.sum_congr rfl fun q _ => ?_
  have h1 (i) : I2.polyDeriv P D
      (fun z => κ * thA X bas idx (heisG X bas (Y q) (heisG X bas (u i) v)) x (N • z)) 0 =
      N ^ d * κ * (1 * I2.polyDeriv P D (thA X bas idx (heisG X bas (Y q) (heisG X bas (u i) v)) x) 0) := by
    have hd := ThetaHol.differentiable_thA idx hs (hsb q i) hx
    rw [_root_.one_mul, _root_.mul_assoc, ← Jet.polyDeriv_smul_fun P D hd, ← Jet.polyDeriv_comp_smul hP N D (hd.const_smul κ)]
    rfl
  have h2 : ∑ i, (1 : ℂ) • heisG X bas (Y q) (heisG X bas (u i) v) = ∑ _i : Unit, t • heisG X bas (Y q) p := by
    funext m
    have := congrFun h (m - Matrix.of fun k i => crd X bas (Y q k) (Sum.inr i))
    simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul] at this
    simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, _root_.one_mul, Finset.univ_unique, Finset.sum_singleton]
    rw [heisG, heisS, ← _root_.mul_assoc, ← this, Finset.sum_mul]
    rfl
  simp only [h1]
  rw [← Finset.mul_sum, ← polyDeriv_thA_sum idx hs hx P D _ _ (hsb q), h2,
    polyDeriv_thA_sum idx hs hx P D _ _ fun _ => (hh _ _ hp).1]
  simp only [Finset.univ_unique, Finset.sum_singleton]
  ring

theorem ex_pow_eq_one {H : Host E} {Dw : Datum H} {l : Geo.Tor.Level H} {Xo : Moduli Dw l} {c : Coeff l}
    [Algebra c.F ℂ] {e : Fin g ≃ Lt1 Dw} {x : Frame X.Ψ r} {L : Lt E r} {y : FrPt Xo c ℂ}
    (A : AnFib X bas idx e x L y) (k : ℕ) (a : Fin r → E) (h : k • a ∈ L) : A.ex (pv X idx x a) ^ k = 1 := by
  have h0 : A.ex 0 = 1 := by
    have := A.ex_add 0 0
    rw [add_zero] at this
    exact left_eq_mul.1 this
  have h1 (j : ℕ) (z) : A.ex (j • z) = A.ex z ^ j := by
    induction j with
    | zero => rw [zero_smul, pow_zero, h0]
    | succ j ih => rw [succ_nsmul, A.ex_add, ih, pow_succ]
  rw [← h1, A.ex_ker]
  refine ⟨_, h, ?_⟩
  rw [← Nat.cast_smul_eq_nsmul E k a, pv_smul]
  funext j
  simp

end GlobalTheory.Dict.ShortVal


open GlobalTheory.Dict.ShortVal in
theorem GlobalTheory.Dict.shortValAt_eq_thP : Formalism.MainNotions.ModuliIntegralCharts.H1.ChartIndepSt2 → ∀ (E : Type) [Field E] [NumberField E] [IsCMField E] (H : Host E) (Dw : Datum H) (l : Geo.Tor.Level H) (Xo : Moduli Dw l) (c : Coeff l) [Algebra c.F ℂ] (r g : ℕ) (X : Data E r) (bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ) (idx : Fin g ≃ X.Ψ × Fin r) (e : Fin g ≃ Lt1 Dw) (x : Frame X.Ψ r) (L : Lt E r) (y : FrPt Xo c ℂ) (A : AnFib X bas idx e x L y), IsSympl X bas → x ∈ X.dom → SelfD X L → ∀ (q0 n : ℕ) (hr : X.p0 + q0 = r) (eL : LtN Dw n ≃ Harm.Var X.Ψ q0 X.p0 (Fin n)), r = Dw.p + Dw.q → Even n → (∀ ℓ, letterDir X hr idx (eL ℓ) = Pi.single ℓ.2.2 (Pi.single (e.symm ⟨ℓ.1, ℓ.2.1⟩) 1)) → ∀ [StarRing (𝓞 E)] (nab : NabV Xo c), IsNab Xo c nab → ∀ (θ : (Fin g → ℂ) → ℂ) (v : TF n g) (κ : ℂ), A.Reads 1 y.s θ → IsVac X bas (H.w0 : E) (tens (stdL E n) L) v → (∀ z : Fin n → Fin g → ℂ, ∏ b, θ (z b) = κ * thA X bas idx v x z) → ∀ mk : Dw.La →ₗ[𝓞 E] (Fin r → E), IsMark l L mk → A.Marked mk → ∀ Λ ∈ Vset E n l.M, ∀ N : ℕ, NOK Λ N l.M → ∀ Y : (Fin n → LevQ Dw l) → Matrix (Fin n) (Fin r) E, IsRoots l L mk N Y → ∀ (a : (E →+* ℂ) × ℕ → ℕ) (P : MvPolynomial (LtN Dw n) c.F), P ∈ HHa Dw.mult n c.F ComplexEmbedding.conjugate (InPsi H) (fun τ i => a (τ, i)) → ∀ (wq : (Fin n → LevQ Dw l) → c.F) (β : c.F) (v0 : ℂ), ShortValAt Xo c nab wq (⟨Λ⟩ : GenLat E n) β N P y v0 → v0 = algebraMap c.F ℂ (β⁻¹ * (((⟨Λ⟩ : GenLat E n).mIdx N r : c.F))⁻¹ * ((Nat.card (Fin n → LevQ Dw l) : c.F))⁻¹ * ((⟨Λ⟩ : GenLat E n).zCard N r : c.F)) * κ * thP X hr bas idx (gphi X bas (H.w0 : E) Λ L v (fun q => algebraMap c.F ℂ (wq q)) Y) (MvPolynomial.rename eL (MvPolynomial.map (algebraMap c.F ℂ) P)) x := by
  intro hC E _ _ _ H Dw l Xo c _ r g X bas idx e x L y A hs hx hL q0 n hr eL hrpq hn hdir _ nab hnab θ v κ hθ hv hκ
    mk hmk hA Λ hΛ N hN Y hY a P hP wq β v0 h0
  subst hrpq
  have hLaws : Laws := firstFiveLaws.1
  haveI := _root_.GlobalTheory.finite_levQ Dw l
  haveI := Fintype.ofFinite (LevQ Dw l)
  obtain ⟨hU, hT⟩ := unimod_trivAt hΛ
  have hodd : Odd N := hN.1
  have hN0 : (N : E) ≠ 0 := Nat.cast_ne_zero.2 hodd.pos.ne'
  have hw : (H.w0 : E) + cc (H.w0 : E) = 1 := by
    rw [cc, ← H.bar_eq]
    exact_mod_cast congrArg (fun t : 𝓞 E => (t : E)) (PullbackSections.CVA.cmHostUnit_add_conj_eq_one H)
  have hΛ1 : Λ ∈ Vset E n 1 := by
    obtain ⟨h1, h2, s, hs, -, h3⟩ := hΛ
    exact ⟨h1, h2, s, hs, Nat.coprime_one_right s, h3⟩
  obtain ⟨u, hu, huinj, hz, -, hsum⟩ := GlobalTheory.T.exists_even_reps_tensorLattice_and_sum E _ X g bas idx n hs hn (H.w0 : E) H.w0.isIntegral_coe hw L hL
    Λ hΛ1 N hodd (hN.2.2.trans inf_le_left)
  obtain ⟨hgeo, hroot⟩ := GlobalTheory.T.analyticFibre_isotropic_points_injective_roots E H Dw l Xo c _ g X bas idx e x L y A hs hx hL n N Λ hodd.pos
  obtain ⟨hZ, hinj⟩ := hgeo _ u hu huinj
  replace hroot := hroot mk hmk hA hN.2.1 Y hY
  have hu2 (i b) : ∃ u' ∈ L, (N ^ 2 : ℕ) • ((N : E)⁻¹ • u i b) = (2 : ℕ) • u' := by
    obtain ⟨u', h1, h2⟩ := (hu i).2 b
    refine ⟨u', h1, ?_⟩
    rw [← h2, ← Nat.cast_smul_eq_nsmul E, ← Nat.cast_smul_eq_nsmul E, smul_smul]
    congr 1
    push_cast
    field_simp
  have htor (t : Fin (Dw.p + Dw.q) → E) (h : ∃ u' ∈ L, (N ^ 2 : ℕ) • t = (2 : ℕ) • u') :
      A.ex (pv X idx x t) ^ (N ^ 2) = 1 := by
    obtain ⟨u', h1, h2⟩ := h
    exact ex_pow_eq_one idx A _ _ (h2 ▸ nsmul_mem h1 2)
  choose F hF using fun q i b => ((exists_isVtOver_and_existsUnique_isUUOver hLaws E H Dw l Xo N hodd
    (ptO Xo y.x) y.s).2 _ _ (htor _ (hu2 i b)) (htor _ (hroot q b).2.2)).exists
  have h1 : ShortValAt Xo c nab wq (⟨Λ⟩ : GenLat E n) β N P y _ :=
    ⟨ℂ, inferInstance, inferInstance, AlgHom.id c.F ℂ, y, _, _, F, RingHom.FaithfullyFlat.of_bijective
      Function.bijective_id, FramedBaseChange.refl y, hZ, hinj, fun q b => ⟨(hroot q b).1, (hroot q b).2.1⟩, hF, rfl⟩
  rw [((shortThetaValue_existsUnique_natural hLaws hC E H Dw l Xo c nab hnab n ⟨Λ⟩ N hU hT hN a P hP wq β).1
    ℂ y).unique h0 h1]
  have hh := (heisG_laws E _ X g bas idx n hs hn).2.2.2
  have hfock := (fock_laws E _ X g bas idx n hs hn x hx 1 θ).2.2.2.2
  have hval (q i) : ∑ m ∈ P.support, algebraMap c.F ℂ (P.coeff m) *
      ∏ b, nab y ((N : ℤ) ^ 2) (F q i b) (colOf m b) =
      I2.polyDeriv (MvPolynomial.map (algebraMap c.F ℂ) P) (letterDir X hr idx ∘ eL)
        (fun z => κ * thA X bas idx (heisG X bas (Y q) (heisG X bas (u i) v)) x ((N : ℂ) • z)) 0 := by
    rw [GlobalTheory.T.harmonicConnectionValue_eq_polynomial_derivative hC E H Dw l Xo c _ g X bas idx e x L y A hs hx hL nab hnab n N a P hP (F q i) _ fun b =>
      (GlobalTheory.T.sections_read_as_translates_at_scaled_point E H Dw l Xo c _ g X bas idx e x L y A hs hx hL N hodd θ hθ).1 _ _ (hu2 i b)
        (hroot q b).2.2 _ (hF q i b)]
    congr 1
    · exact funext fun ℓ => (hdir ℓ).symm
    · funext z
      simp only [smul_inv_smul₀ hN0]
      exact hfock _ κ _ (hh (u i) v hv.1).1 (hfock (fun _ => θ) κ v hv.1 hκ (u i)) (Y q) ((N : ℂ) • z)
  have hsum' := hsum v hv
  have hz' : (((⟨Λ⟩ : GenLat E n).zCard N (Dw.p + Dw.q) : ℕ) : ℂ) ≠ 0 := Nat.cast_ne_zero.2 hz.ne'
  have hp : IsSB (projA X bas (H.w0 : E) (tens Λ L) v) := by
    have := isSB_smul (((⟨Λ⟩ : GenLat E n).zCard N (Dw.p + Dw.q) : ℕ) : ℂ)⁻¹
      (hsum' ▸ isSB_sum Finset.univ _ fun i => (hh (u i) v hv.1).1)
    rwa [inv_smul_smul₀ hz'] at this
  have hhom := (isHomogeneous_of_rowDeg hP.2.2).map (algebraMap c.F ℂ)
  have hg : IsSB (∑ q, algebraMap c.F ℂ (wq q) • heisG X bas (Y q) (projA X bas (H.w0 : E) (tens Λ L) v)) :=
    isSB_sum _ _ fun q => isSB_smul _ (hh _ _ hp).1
  simp only [hval]
  rw [finsum_eq_sum_of_fintype, sum_polyDeriv idx hs hn hx hhom _ _ Y u hv.1 hp hsum', thP, gphi,
    finsum_eq_sum_of_fintype, polyDeriv_rename ((SCV.analyticOnNhd_of_differentiable
      (ThetaHol.differentiable_thA idx hs hg hx) Set.univ 0 trivial).contDiffAt) _ eL.injective]
  have hNc : (N : ℂ) ^ P.totalDegree ≠ 0 := pow_ne_zero _ (Nat.cast_ne_zero.2 hodd.pos.ne')
  simp only [map_mul, map_inv₀, map_pow, map_natCast]
  have key (a b c d t s : ℂ) : a * b * c * ((N : ℂ) ^ P.totalDegree)⁻¹ * ((N : ℂ) ^ P.totalDegree * d * t * s) =
      a * b * c * d * t * s := by field_simp
  exact key _ _ _ _ _ _

-- clump-header: {"m": "Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRoots", "h": "module\n\npublic import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsStabForm\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.HermitianFormAtFrameLaws\nimport Mathlib.Algebra.Order.Floor.Extended\nimport Mathlib.Algebra.Order.Floor.Semifield\nimport Mathlib.Algebra.Order.Interval.Basic\nimport Mathlib.Analysis.Complex.UpperHalfPlane.Basic\nimport Mathlib.Analysis.Normed.Algebra.GelfandRadius\nimport Mathlib.Analysis.SpecialFunctions.Bernstein\nimport Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp\nimport Mathlib.Combinatorics.Enumerative.DyckWord\nimport Mathlib.Combinatorics.SimpleGraph.Triangle.Removal\nimport Mathlib.Data.NNRat.Floor\nimport Mathlib.Data.Nat.Choose.Multinomial\nimport Mathlib.Geometry.Euclidean.Volume.Basic\nimport Mathlib.NumberTheory.Chebyshev\nimport Mathlib.NumberTheory.Height.NumberField\nimport Mathlib.NumberTheory.Height.Projectivization\nimport Mathlib.NumberTheory.LucasLehmer\nimport Mathlib.NumberTheory.SelbergSieve\nimport Mathlib.RingTheory.Henselian\nimport Mathlib.RingTheory.Radical.NatInt\nimport Mathlib.RingTheory.RegularLocalRing.Defs\nimport Mathlib.Tactic.Echelon.Zsqrtd\nimport Mathlib.Tactic.Inclusion.Extension.Core.Core\nimport Mathlib.Tactic.Inclusion.Extension.Interval.BinarySplit\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Exp\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Hypotheses\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Basic\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Hypotheses\nimport Mathlib.Tactic.Linter.HaveILetI\nimport Mathlib.Tactic.Linter.Style\nimport Mathlib.Tactic.NormNum.Irrational\nimport Mathlib.Tactic.NormNum.IsCoprime\nimport Mathlib.Tactic.NormNum.IsSquare\nimport Mathlib.Tactic.NormNum.LegendreSymbol\nimport Mathlib.Tactic.NormNum.ModEq\nimport Mathlib.Tactic.NormNum.NatFib\nimport Mathlib.Tactic.NormNum.NatLog\nimport Mathlib.Tactic.NormNum.NatSqrt\nimport Mathlib.Tactic.NormNum.Ordinal\nimport Mathlib.Tactic.NormNum.Parity\nimport Mathlib.Tactic.NormNum.Prime\nimport Mathlib.Tactic.NormNum.RealSqrt\n\n"}
-- clump-header: {"m": "Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRootsStatement", "h": "module\n\npublic import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsStabForm\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRoots\nimport Mathlib.Algebra.Order.Floor.Extended\nimport Mathlib.Algebra.Order.Floor.Semifield\nimport Mathlib.Algebra.Order.Interval.Basic\nimport Mathlib.Analysis.Complex.UpperHalfPlane.Basic\nimport Mathlib.Analysis.Normed.Algebra.GelfandRadius\nimport Mathlib.Analysis.SpecialFunctions.Bernstein\nimport Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp\nimport Mathlib.Combinatorics.Enumerative.DyckWord\nimport Mathlib.Combinatorics.SimpleGraph.Triangle.Removal\nimport Mathlib.Data.NNRat.Floor\nimport Mathlib.Data.Nat.Choose.Multinomial\nimport Mathlib.Geometry.Euclidean.Volume.Basic\nimport Mathlib.NumberTheory.Chebyshev\nimport Mathlib.NumberTheory.Height.NumberField\nimport Mathlib.NumberTheory.Height.Projectivization\nimport Mathlib.NumberTheory.LucasLehmer\nimport Mathlib.NumberTheory.SelbergSieve\nimport Mathlib.RingTheory.Radical.NatInt\nimport Mathlib.Tactic.Echelon.Zsqrtd\nimport Mathlib.Tactic.Inclusion.Extension.Core.Core\nimport Mathlib.Tactic.Inclusion.Extension.Interval.BinarySplit\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Exp\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Hypotheses\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Basic\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Hypotheses\nimport Mathlib.Tactic.NormNum.Irrational\nimport Mathlib.Tactic.NormNum.IsCoprime\nimport Mathlib.Tactic.NormNum.IsSquare\nimport Mathlib.Tactic.NormNum.LegendreSymbol\nimport Mathlib.Tactic.NormNum.ModEq\nimport Mathlib.Tactic.NormNum.NatFib\nimport Mathlib.Tactic.NormNum.NatLog\nimport Mathlib.Tactic.NormNum.NatSqrt\nimport Mathlib.Tactic.NormNum.Ordinal\nimport Mathlib.Tactic.NormNum.Parity\nimport Mathlib.Tactic.NormNum.Prime\nimport Mathlib.Tactic.NormNum.RealSqrt\n\n"}
-- clump-header: {"m": "Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEvenRepsTensorLatticeAndSumStatement", "h": "module\n\npublic import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsSystem\npublic import Formalism.LocalToGlobal.ProjectiveLattices.ThShort\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEvenRepsTensorLatticeAndSum\nimport Mathlib.Algebra.Order.Floor.Extended\nimport Mathlib.Algebra.Order.Floor.Semifield\nimport Mathlib.Algebra.Order.Interval.Basic\nimport Mathlib.Analysis.Complex.UpperHalfPlane.Basic\nimport Mathlib.Analysis.Normed.Algebra.GelfandRadius\nimport Mathlib.Analysis.SpecialFunctions.Bernstein\nimport Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp\nimport Mathlib.Combinatorics.Enumerative.DyckWord\nimport Mathlib.Combinatorics.SimpleGraph.Triangle.Removal\nimport Mathlib.Data.NNRat.Floor\nimport Mathlib.Data.Nat.Choose.Multinomial\nimport Mathlib.Geometry.Euclidean.Volume.Basic\nimport Mathlib.NumberTheory.Chebyshev\nimport Mathlib.NumberTheory.Height.NumberField\nimport Mathlib.NumberTheory.Height.Projectivization\nimport Mathlib.NumberTheory.LucasLehmer\nimport Mathlib.NumberTheory.SelbergSieve\nimport Mathlib.RingTheory.Radical.NatInt\nimport Mathlib.Tactic.Echelon.Zsqrtd\nimport Mathlib.Tactic.Inclusion.Extension.Core.Core\nimport Mathlib.Tactic.Inclusion.Extension.Interval.BinarySplit\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Exp\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Hypotheses\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Basic\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Hypotheses\nimport Mathlib.Tactic.NormNum.Irrational\nimport Mathlib.Tactic.NormNum.IsCoprime\nimport Mathlib.Tactic.NormNum.IsSquare\nimport Mathlib.Tactic.NormNum.LegendreSymbol\nimport Mathlib.Tactic.NormNum.ModEq\nimport Mathlib.Tactic.NormNum.NatFib\nimport Mathlib.Tactic.NormNum.NatLog\nimport Mathlib.Tactic.NormNum.NatSqrt\nimport Mathlib.Tactic.NormNum.Ordinal\nimport Mathlib.Tactic.NormNum.Parity\nimport Mathlib.Tactic.NormNum.Prime\nimport Mathlib.Tactic.NormNum.RealSqrt\nimport Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsStabForm\nimport Formalism.LocalToGlobal.ProjectiveLattices.JFDFree\n\n"}
-- clump-header: {"m": "Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ShortThetaValueComplexPointEqClassicalTheta", "h": "module\n\npublic import Development.AbelianVarietyTheory.Definitions.SpanningFamilies.IsBaseClassLevelAdapted\npublic import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ThExprUniqOfChartIndep2\npublic import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.TaylorDiscriminants.Taylor\npublic import Development.AbelianVarietyTheory.Proofs.CovolumeBounds.DifferentiableOnOfTendstoLocallyUniformlyOn\npublic import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.CardToMultisetEqDegree\npublic import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.ExistsTranslationSectionsUniversalObject\npublic import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.FramedPointBaseChangeLaws\npublic import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.ShortThetaValueExistsUniqueNaturalOfLaws\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.AnalyticFibreIsotropicPointsInjectiveRootsStatement\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEvenRepsTensorLatticeAndSumStatement\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.FockHxDifferentiable\nimport Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.HMatMulVecPerCrd\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.HarmonicConnectionValueEqPolynomialDerivativeStatement\nimport Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.HermitianFormAtFrameLaws\nimport Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.RationalSchwartzBruhatAlgebraIntegralLinear\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.SectionsReadAsTranslatesAtScaledPointStatement\npublic import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ThetaSeriesTestFunctionHolomorphicWeight\nimport Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.WeilActionPreservesThetaAndInnerProduct\npublic import Development.AbelianVarietyTheory.Proofs.UniformizationProofs.AllUniformizationLawsHold\nimport Mathlib.Algebra.Order.Floor.Extended\nimport Mathlib.Algebra.Order.Floor.Semifield\nimport Mathlib.Algebra.Order.Interval.Basic\nimport Mathlib.Analysis.Complex.UpperHalfPlane.Basic\nimport Mathlib.Analysis.Normed.Algebra.GelfandRadius\nimport Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp\nimport Mathlib.Combinatorics.Enumerative.DyckWord\nimport Mathlib.Combinatorics.SimpleGraph.Triangle.Removal\nimport Mathlib.Data.NNRat.Floor\nimport Mathlib.Geometry.Euclidean.Volume.Basic\nimport Mathlib.NumberTheory.Chebyshev\nimport Mathlib.NumberTheory.Height.NumberField\nimport Mathlib.NumberTheory.Height.Projectivization\nimport Mathlib.NumberTheory.LucasLehmer\nimport Mathlib.NumberTheory.SelbergSieve\nimport Mathlib.RingTheory.Coalgebra.IsFrobenius\nimport Mathlib.RingTheory.Henselian\nimport Mathlib.RingTheory.Radical.NatInt\nimport Mathlib.RingTheory.RegularLocalRing.Defs\nimport Mathlib.RingTheory.WittVector.IsPoly\nimport Mathlib.Tactic.Basify\nimport Mathlib.Tactic.ENatToNat\nimport Mathlib.Tactic.Echelon.Zsqrtd\nimport Mathlib.Tactic.Inclusion.Extension.Core.Core\nimport Mathlib.Tactic.Inclusion.Extension.Interval.BinarySplit\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Exp\nimport Mathlib.Tactic.Inclusion.Extension.IntervalDyadicReal.Hypotheses\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Basic\nimport Mathlib.Tactic.Inclusion.Extension.IntervalInt.Hypotheses\nimport Mathlib.Tactic.NormNum.Irrational\nimport Mathlib.Tactic.NormNum.IsCoprime\nimport Mathlib.Tactic.NormNum.IsSquare\nimport Mathlib.Tactic.NormNum.LegendreSymbol\nimport Mathlib.Tactic.NormNum.ModEq\nimport Mathlib.Tactic.NormNum.NatFib\nimport Mathlib.Tactic.NormNum.NatLog\nimport Mathlib.Tactic.NormNum.NatSqrt\nimport Mathlib.Tactic.NormNum.Ordinal\nimport Mathlib.Tactic.NormNum.Parity\nimport Mathlib.Tactic.NormNum.Prime\nimport Mathlib.Tactic.NormNum.RealSqrt\nimport Mathlib.Tactic.Polynomial.Basic\nimport Mathlib.Tactic.ReduceModChar\npublic import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.PullbackSections.HolomorphicFamilies.CmHostUnitAddConjEqOne\n\n"}
